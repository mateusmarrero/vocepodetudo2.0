<?php
/**
 * API de Cursos (Leitura Pública & Gravação Restrita a Administradores)
 * Portal Você Pode Tudo
 */

require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? ($method === 'POST' ? 'create' : ($method === 'DELETE' ? 'delete' : 'list'));
$pdo = getDBConnection();

// Obter dados de entrada (JSON, POST ou GET)
$rawInput = file_get_contents('php://input');
$inputData = json_decode($rawInput, true) ?? $_POST;
if (empty($inputData)) {
    $inputData = $_GET;
}

switch ($action) {
    case 'list':
        // Leitura: Retorna cursos (ativos por padrão, ou todos caso admin solicite)
        $isAdminRequest = !empty($_GET['admin']) || !empty($_GET['all']);
        $whereClause = $isAdminRequest ? "1=1" : "is_active = 1";

        try {
            $stmt = $pdo->query("
                SELECT 
                    id,
                    title,
                    provider,
                    provider_tag AS providerTag,
                    provider_color AS providerColor,
                    category,
                    description,
                    url,
                    workload_hours AS workloadHours,
                    has_free_certificate AS hasFreeCertificate,
                    certificate_note AS certificateNote,
                    level,
                    tags,
                    featured,
                    rating,
                    reviews_count AS reviewsCount,
                    is_active AS isActive,
                    created_at AS createdAt
                FROM courses 
                WHERE {$whereClause}
                ORDER BY featured DESC, rating DESC, id DESC
            ");

            $rows = $stmt->fetchAll();

            $courses = array_map(function($c) {
                return [
                    'id' => $c['id'],
                    'title' => $c['title'],
                    'provider' => $c['provider'],
                    'providerTag' => $c['providerTag'] ?: substr($c['provider'], 0, 15),
                    'providerColor' => $c['providerColor'] ?: 'bg-slate-100 text-slate-800 border-slate-300 font-bold',
                    'category' => $c['category'],
                    'categoryName' => $c['category'],
                    'description' => $c['description'] ?: '',
                    'url' => $c['url'],
                    'workloadHours' => (int) $c['workloadHours'],
                    'hasFreeCertificate' => (bool) $c['hasFreeCertificate'],
                    'certificateNote' => $c['certificateNote'] ?: ($c['hasFreeCertificate'] ? 'Certificado 100% Gratuito' : 'Modo Ouvinte Gratuito'),
                    'level' => $c['level'] ?: 'Iniciante',
                    'tags' => !empty($c['tags']) ? (json_decode($c['tags'], true) ?: array_map('trim', explode(',', $c['tags']))) : [],
                    'featured' => (bool) $c['featured'],
                    'rating' => (float) ($c['rating'] ?: 5.0),
                    'reviewsCount' => (int) ($c['reviewsCount'] ?: 100),
                    'isActive' => (bool) ($c['isActive'] ?? true)
                ];
            }, $rows);

            jsonResponse([
                'success' => true,
                'count' => count($courses),
                'courses' => $courses
            ]);
        } catch (PDOException $e) {
            error_log("Erro ao buscar cursos: " . $e->getMessage());
            jsonResponse(['error' => true, 'message' => 'Erro ao consultar catálogo no banco.'], 500);
        }
        break;

    case 'create':
        // Cadastrar Novo Curso: Somente Administrador
        requireAuth();

        $title = trim($inputData['title'] ?? '');
        $provider = trim($inputData['provider'] ?? '');
        $category = trim($inputData['category'] ?? 'tecnologia');
        $url = trim($inputData['url'] ?? '');
        $workloadHours = (int) ($inputData['workloadHours'] ?? 20);
        $hasFreeCert = !empty($inputData['hasFreeCertificate']) ? 1 : 0;
        $level = trim($inputData['level'] ?? 'Iniciante');
        $desc = trim($inputData['description'] ?? '');
        $featured = !empty($inputData['featured']) ? 1 : 0;

        if (empty($title) || empty($provider) || empty($url)) {
            jsonResponse(['error' => true, 'message' => 'Título, instituição e link oficial são obrigatórios.'], 400);
        }

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            jsonResponse(['error' => true, 'message' => 'O link informado não é uma URL válida.'], 400);
        }

        $id = 'curso-' . time() . '-' . mt_rand(100, 999);
        $providerTag = mb_substr($provider, 0, 15);
        $providerColor = 'bg-emerald-50 text-emerald-900 border-emerald-300 font-black';
        $tagsJson = json_encode(['Oficial', 'Novo', $provider], JSON_UNESCAPED_UNICODE);
        $certNote = $hasFreeCert ? 'Certificado 100% Gratuito' : 'Modo Ouvinte Gratuito';

        try {
            $stmt = $pdo->prepare("
                INSERT INTO courses (
                    id, title, provider, provider_tag, provider_color, category, 
                    description, url, workload_hours, has_free_certificate, 
                    certificate_note, level, tags, featured, rating, reviews_count, is_active
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, 
                    ?, ?, ?, ?, 
                    ?, ?, ?, ?, 5.0, 1, 1
                )
            ");

            $stmt->execute([
                $id, $title, $provider, $providerTag, $providerColor, $category,
                $desc, $url, $workloadHours, $hasFreeCert,
                $certNote, $level, $tagsJson, $featured
            ]);

            jsonResponse([
                'success' => true,
                'message' => 'Curso adicionado com sucesso no banco de dados MySQL!',
                'course' => [
                    'id' => $id,
                    'title' => $title,
                    'provider' => $provider,
                    'category' => $category,
                    'url' => $url,
                    'workloadHours' => $workloadHours,
                    'hasFreeCertificate' => (bool)$hasFreeCert,
                    'certificateNote' => $certNote,
                    'level' => $level,
                    'featured' => (bool)$featured,
                    'isActive' => true
                ]
            ], 201);
        } catch (PDOException $e) {
            error_log("Erro ao salvar curso no MySQL: " . $e->getMessage());
            jsonResponse(['error' => true, 'message' => 'Erro ao gravar curso no banco de dados.'], 500);
        }
        break;

    case 'update':
        // Atualizar Curso Existente: Somente Administrador
        requireAuth();

        $id = trim($inputData['id'] ?? '');
        $title = trim($inputData['title'] ?? '');
        $provider = trim($inputData['provider'] ?? '');
        $category = trim($inputData['category'] ?? '');
        $url = trim($inputData['url'] ?? '');
        $workloadHours = isset($inputData['workloadHours']) ? (int)$inputData['workloadHours'] : null;
        $hasFreeCert = isset($inputData['hasFreeCertificate']) ? (!empty($inputData['hasFreeCertificate']) ? 1 : 0) : null;
        $desc = isset($inputData['description']) ? trim($inputData['description']) : null;
        $featured = isset($inputData['featured']) ? (!empty($inputData['featured']) ? 1 : 0) : null;

        if (empty($id)) {
            jsonResponse(['error' => true, 'message' => 'ID do curso obrigatório.'], 400);
        }

        try {
            $stmt = $pdo->prepare("
                UPDATE courses SET
                    title = COALESCE(NULLIF(?, ''), title),
                    provider = COALESCE(NULLIF(?, ''), provider),
                    category = COALESCE(NULLIF(?, ''), category),
                    url = COALESCE(NULLIF(?, ''), url),
                    workload_hours = COALESCE(?, workload_hours),
                    has_free_certificate = COALESCE(?, has_free_certificate),
                    description = COALESCE(?, description),
                    featured = COALESCE(?, featured)
                WHERE id = ?
            ");

            $stmt->execute([
                $title, $provider, $category, $url,
                $workloadHours, $hasFreeCert, $desc, $featured,
                $id
            ]);

            jsonResponse([
                'success' => true,
                'message' => 'Curso atualizado com sucesso!'
            ]);
        } catch (PDOException $e) {
            error_log("Erro ao atualizar curso: " . $e->getMessage());
            jsonResponse(['error' => true, 'message' => 'Erro ao atualizar curso no banco.'], 500);
        }
        break;

    case 'toggle':
        // Alternar Ativo/Inativo: Somente Administrador
        requireAuth();

        $id = trim($inputData['id'] ?? '');
        if (empty($id)) {
            jsonResponse(['error' => true, 'message' => 'ID do curso não informado.'], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE courses SET is_active = IF(is_active = 1, 0, 1) WHERE id = ?");
            $stmt->execute([$id]);

            $stmtCheck = $pdo->prepare("SELECT is_active FROM courses WHERE id = ?");
            $stmtCheck->execute([$id]);
            $newState = (int)$stmtCheck->fetchColumn();

            jsonResponse([
                'success' => true,
                'message' => $newState === 1 ? 'Curso ativado com sucesso.' : 'Curso pausado/desativado do catálogo.',
                'isActive' => $newState === 1
            ]);
        } catch (PDOException $e) {
            error_log("Erro ao alternar status do curso: " . $e->getMessage());
            jsonResponse(['error' => true, 'message' => 'Erro ao alterar status.'], 500);
        }
        break;

    case 'delete':
        // Exclusão / Desativação: Somente Administrador Autenticado
        requireAuth();

        $courseId = trim($inputData['id'] ?? '');
        if (empty($courseId)) {
            jsonResponse(['error' => true, 'message' => 'ID do curso não informado.'], 400);
        }

        try {
            // Desativar logicamente (soft delete)
            $stmt = $pdo->prepare("UPDATE courses SET is_active = 0 WHERE id = ?");
            $stmt->execute([$courseId]);

            jsonResponse([
                'success' => true,
                'message' => 'Curso desativado do catálogo com sucesso.'
            ]);
        } catch (PDOException $e) {
            error_log("Erro ao desativar curso: " . $e->getMessage());
            jsonResponse(['error' => true, 'message' => 'Erro ao remover curso do banco.'], 500);
        }
        break;

    default:
        jsonResponse(['error' => true, 'message' => 'Ação não reconhecida.'], 405);
}
